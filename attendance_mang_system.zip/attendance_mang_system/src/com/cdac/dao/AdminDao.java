package com.cdac.dao;

import java.util.List;

import com.cdac.dto.Student;

public interface AdminDao {
	void insertStudent(Student student);
	void deleteStudent(int studentId);
	Student selectStudent(int studentId);
	void updateStudent(Student student);
	List<Student> selectAll(int studentId);
	List<Student> selectAll();
}
