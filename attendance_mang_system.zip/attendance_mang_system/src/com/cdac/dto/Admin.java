package com.cdac.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="admin")
public class Admin {
	@Id
	@GeneratedValue
	@Column(name="admin_id")
	private int AdminId;
	@Column(name="user_name")	
	private String userName;
	@Column(name="password")
	private String Password;
	public Admin() {
		super();
	}
	public Admin(String userName,String Password) {
		super();
		this.userName = "Admin";
		Password = "Admin123";
	}
	public int getAdminId() {
		return AdminId;
	}


	public void setAdminId(int adminId) {
		AdminId = adminId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return Password;
	}
	public void setPassword(String password) {
		Password = password;
	}

}
