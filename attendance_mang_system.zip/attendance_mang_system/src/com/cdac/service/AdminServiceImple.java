package com.cdac.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cdac.dao.AdminDao;
import com.cdac.dao.StudentDao;
import com.cdac.dto.Student;
@Service
public class AdminServiceImple implements AdminService{

	@Autowired
	private StudentDao studentDao;
	@Autowired
	private AdminDao  adminDao;
	@Override
	public void addStudent(Student student) {
		studentDao.insertStudent(student);

	}

	@Override
	public void removeStudent(int studentId) {

		adminDao.deleteStudent(studentId);
	}

	@Override
	public Student findStudent(int studentId) {

		return adminDao.selectStudent(studentId);
	}

	@Override
	public void modifyStudent(Student student) {
		adminDao.updateStudent(student);
	}

	@Override
	public List<Student> selectAll(int studentId) {
		// TODO Auto-generated method stub
		return adminDao.selectAll(studentId);
	}

	@Override
	public List<Student> selectAll() {

		return adminDao.selectAll();
	}



}
