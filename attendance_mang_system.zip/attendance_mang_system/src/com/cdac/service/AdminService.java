package com.cdac.service;

import java.util.List;


import com.cdac.dto.Student;

public interface AdminService {
	void addStudent(Student student);
	void removeStudent(int studentId);
	Student findStudent(int studentId);
	void modifyStudent(Student student);
	List<Student> selectAll(int studentId);
	List<Student> selectAll();
}
