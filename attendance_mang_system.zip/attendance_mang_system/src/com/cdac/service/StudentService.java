package com.cdac.service;

import java.util.List;

import com.cdac.dto.Student;

public interface StudentService {
	void addStudent(Student student);
	boolean findStudent(Student student);
	//Student viewProfile(int studentId);
	List<Student> selectAll();
}
