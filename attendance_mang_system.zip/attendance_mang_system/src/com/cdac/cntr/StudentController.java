package com.cdac.cntr;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cdac.dto.Admin;
import com.cdac.dto.Student;
import com.cdac.service.AdminService;
//import com.cdac.service.AdminService;
import com.cdac.service.StudentService;

@Controller
public class StudentController {
@Autowired
private StudentService studentService;
//@Autowired
//private StudentValidator studentValidator;

@RequestMapping(value = "/prep_reg_form.htm",method = RequestMethod.GET)
public String prepRegForm(ModelMap map) {
	map.put("student", new Student());
	return "reg_form";
}

@RequestMapping(value = "/reg.htm",method = RequestMethod.POST)
public String register(Student student,ModelMap map) {
	System.out.println(student);
	studentService.addStudent(student);
	
	return "index";
}

@RequestMapping(value = "/prep_log_form.htm",method = RequestMethod.GET)
public String prepLogForm(ModelMap map) {
	map.put("student", new Student());
	return "login_form";
}


@RequestMapping(value = "/login.htm",method = RequestMethod.POST)
public String login(Student student,BindingResult result,ModelMap map,HttpSession session) {
	
	//studentValidator.validate(student, result);
	/*if(result.hasErrors()) {
		return "login_form";
	}*/
	
	boolean b = studentService.findStudent(student);
	if(b) {
		session.setAttribute("student", student); 
		return "student_attendance";
	}else {
		map.put("student", new Student());
		return "login_form";
	}
}
/*@RequestMapping(value = "/admin_log_form.htm",method = RequestMethod.GET)
public String adminLogForm(ModelMap map) {
	map.put("admin", new Admin());
	return "login_form";
}*/


/*@RequestMapping(value = "/adminlog.htm",method = RequestMethod.POST)
public String register(Admin admin,ModelMap map) {
	AdminService.addAdmin(admin);
	return "index";
}*/

@RequestMapping(value = "/view_attendance.htm",method = RequestMethod.GET)
public String allStudents(ModelMap map,HttpSession session) {
	//int userId = ((User)session.getAttribute("user")).getUserId();
	List<Student> li = studentService.selectAll();
	map.put("stdList", li);
	return "attendance";
}
@RequestMapping(value = "/index.htm",method = RequestMethod.GET)
public String logout(ModelMap map,HttpSession session) {
	map.put("student", new Student());
	//int userId = ((User)session.getAttribute("user")).getUserId();
	//session.invalidate();
	if(session.getAttribute("student")!=null) {
		session.removeAttribute("student");
		List<Student> li = studentService.selectAll();
		map.put("stdList", li);
		return "login_form";
	}
	return null;
	
	
}
}
