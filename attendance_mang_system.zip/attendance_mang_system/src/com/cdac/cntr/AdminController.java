package com.cdac.cntr;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cdac.dto.Admin;
import com.cdac.dto.Student;
import com.cdac.service.AdminService;
import com.cdac.service.StudentService;

@Controller
public class AdminController {
	@Autowired
	private AdminService adminService;
	@RequestMapping(value="/admin_log_form.htm")
	public String prepareAdminLogin(ModelMap map) {
		map.put("admin", new Admin());
		return "admin_log";
	}

	@RequestMapping(value="/adminLogin.htm",method = RequestMethod.POST)
	public String AdminLoginFinal(Admin admin,ModelMap map,HttpSession session) {
		session.setAttribute("admin", admin);
		if(admin.getUserName().equals("Admin") && admin.getPassword().equals("Admin123")) {
			return "admin_home";
		}else {
			return "admin_log";
		}

		
	}
	

	
	@RequestMapping(value = "/prep_expense_add_form.htm",method = RequestMethod.GET)
	public String prepExpenseAddForm(ModelMap map) {
		map.put("student", new Student());
		return "student_add_form";
	}
	
	/*@RequestMapping(value = "/expense_add.htm",method = RequestMethod.POST)
	public String expenseAdd(Expense expense,HttpSession session) {
		int userId = ((User)session.getAttribute("user")).getUserId();
		expense.setUserId(userId); 
		expenseService.addExpense(expense);
		return "home";
	}*/
	
	@RequestMapping(value = "/expense_list.htm",method = RequestMethod.GET)
	public String allStudent(ModelMap map,HttpSession session) {
		//int userId = ((User)session.getAttribute("user")).getUserId();
		List<Student> li = adminService.selectAll();
		map.put("stdList", li);
		return "student_list";
	}
	
	@RequestMapping(value = "/student_delete.htm",method = RequestMethod.GET)
	public String studentDelete(@RequestParam int studentId,ModelMap map,HttpSession session) {
		System.out.println(studentId);
		adminService.removeStudent(studentId); 
		
		//int studentId1 = ((Student)session.getAttribute("student")).getStudentId();
		//System.out.println(studentId1);
		List<Student> li = adminService.selectAll();
		map.put("stdList", li);
		return "student_list";
	}
	
	@RequestMapping(value = "/student_update_form.htm",method = RequestMethod.GET)
	public String studentUpdateRecord(@RequestParam int studentId,ModelMap map) {
		
		Student exp = adminService.findStudent(studentId);
		map.put("student", exp);
		
		return "student_update_form";
	}
	
	@RequestMapping(value = "/student_update.htm",method = RequestMethod.POST)
	public String studentUpdate(Student student,ModelMap map,HttpSession session) {
		
		//int userId = ((Student)session.getAttribute("user")).getUserId();
		//expense.setUserId(userId);
		adminService.modifyStudent(student);
			
		List<Student> li = adminService.selectAll();
		map.put("stdList", li);
		return "student_list";
	}
	@RequestMapping(value = "/view_attendance1.htm",method = RequestMethod.GET)
	public String allStudents(ModelMap map,HttpSession session) {
		//int userId = ((User)session.getAttribute("user")).getUserId();
		List<Student> li = adminService.selectAll();
		map.put("stdList", li);
		return "admin_attendance";
	}
	
	
}
